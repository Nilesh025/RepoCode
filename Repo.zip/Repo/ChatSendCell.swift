//
//  ChatSendCell.swift
//  Intro
//
//  Created by webmigrates on 25/02/19.
//  Copyright © 2019 Developer. All rights reserved.
//

import UIKit

class ChatSendCell: UITableViewCell {

    @IBOutlet weak var lblMessage: UILabel!
    @IBOutlet weak var lblType: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
