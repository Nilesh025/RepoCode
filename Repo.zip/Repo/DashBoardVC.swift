//
//  DashBoardVC.swift
//  tabdemo
//
//  Created by wm-nilesh on 28/05/19.
//  Copyright © 2019 webmigrates. All rights reserved.
//

import UIKit
import Starscream

class DashBoardVC: UIViewController,WebSocketDelegate{
    

    @IBOutlet weak var TabContainerView: UIView!
    @IBOutlet weak var TabbarView: UIView!
    @IBOutlet weak var Tab1DefaultView: UIImageView!
    @IBOutlet weak var Tab1CustomeView: UIImageView!
    @IBOutlet weak var Tab2DefaultView: UIView!
    @IBOutlet weak var Tab2CustomeView: UIView!
    @IBOutlet weak var Tab3DefaultView: UIView!
    @IBOutlet weak var Tab3customeView: UIView!
    @IBOutlet weak var Tab4DefaultView: UIView!
    @IBOutlet weak var Tab4customeView: UIView!
    @IBOutlet weak var Tab5defaultView: UIView!
    @IBOutlet weak var Tab5CustomeView: UIView!
    
    var isSendConnection = false
    var acceptConnection = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        kAppDelegate.Socket.delegate = self
        kAppDelegate.Socket.connect()
        
        if isSendConnection {
            self.OpenConnectionReqByNotification()
        }
        else if acceptConnection {
            btnMyConnectionClick(UIButton())
        }
        else {
            btnEventClick(UIButton())
        }
       
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
       
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.isSendConnection = false
        self.acceptConnection = false
    }
    
    func websocketDidConnect(socket: WebSocketClient) {
        print("Connection Done")
        
        let dictionary = ["token":GetAPIToken(),
                          "hookMethod": "registration"]
        if let theJSONData = try? JSONSerialization.data(
            withJSONObject: dictionary,
            options: []) {
            let theJSONText = String(data: theJSONData,
                                     encoding: .ascii)
            print("JSON string = \(theJSONText!)")
            kAppDelegate.Socket.write(string: "\(theJSONText!)")
        }
    }
    
    func websocketDidDisconnect(socket: WebSocketClient, error: Error?) {
        if let e = error as? WSError {
            print("websocket is disconnected: \(e.message)")
        } else if let e = error {
            print("websocket is disconnected: \(e.localizedDescription)")
        } else {
            print("websocket disconnected")
        }
    }
    func websocketDidReceiveMessage(socket: WebSocketClient, text: String) {
        print("Connection Done did receive sms")
    }
    
    func websocketDidReceiveData(socket: WebSocketClient, data: Data) {
        print("Connection Done did receive data")
    }
    
    @IBAction func btnEventClick(_ sender: Any) {
        
        strDate = ""
        EndDate = ""
        GotfirstTime = ""
        GotlastTime = ""
        GotMile = ""
        GotCatID = ""
        selectedCat = ""
        GotRelID = ""
        selectedRligion = ""
        GotChurchID = ""
        selectedCurch = ""
        isfilter = false
        
        TabContainerView.subviews.forEach({ $0.removeFromSuperview() })
        let containerView = UIView()
        containerView.translatesAutoresizingMaskIntoConstraints = false
        TabContainerView.addSubview(containerView)
        
        Tab1CustomeView.isHidden = false
        
        Tab2CustomeView.isHidden = true
        Tab3customeView.isHidden = true
        Tab4customeView.isHidden = true
        Tab5CustomeView.isHidden = true
        
        NSLayoutConstraint.activate([
            containerView.leadingAnchor.constraint(equalTo: TabContainerView.leadingAnchor, constant: 0),
            containerView.trailingAnchor.constraint(equalTo: TabContainerView.trailingAnchor, constant: 0),
            containerView.topAnchor.constraint(equalTo: TabContainerView.topAnchor, constant: 0),
            containerView.bottomAnchor.constraint(equalTo: TabContainerView.bottomAnchor, constant: 0),
            ])
        
        
        let controller = storyboard!.instantiateViewController(withIdentifier: "MyEventVC") as! MyEventVC
        addChild(controller)
        controller.view.translatesAutoresizingMaskIntoConstraints = false
        TabContainerView.addSubview(controller.view)
        
        NSLayoutConstraint.activate([
            controller.view.leadingAnchor.constraint(equalTo: TabContainerView.leadingAnchor),
            controller.view.trailingAnchor.constraint(equalTo: TabContainerView.trailingAnchor),
            controller.view.topAnchor.constraint(equalTo: TabContainerView.topAnchor),
            controller.view.bottomAnchor.constraint(equalTo: TabContainerView.bottomAnchor)
            ])
        
        controller.didMove(toParent: self)
        
        
    }
    
    @IBAction func btnDonationclick(_ sender: Any) {
        
        strDate = ""
        EndDate = ""
        GotfirstTime = ""
        GotlastTime = ""
        GotMile = ""
        GotCatID = ""
        selectedCat = ""
        GotRelID = ""
        selectedRligion = ""
        GotChurchID = ""
        selectedCurch = ""
        isfilter = false
        
        TabContainerView.subviews.forEach({ $0.removeFromSuperview() })
        let containerView = UIView()
        containerView.translatesAutoresizingMaskIntoConstraints = false
        TabContainerView.addSubview(containerView)
        Tab2CustomeView.isHidden = false
        
        Tab1CustomeView.isHidden = true
        Tab3customeView.isHidden = true
        Tab4customeView.isHidden = true
        Tab5CustomeView.isHidden = true
        
        NSLayoutConstraint.activate([
            containerView.leadingAnchor.constraint(equalTo: TabContainerView.leadingAnchor, constant: 0),
            containerView.trailingAnchor.constraint(equalTo: TabContainerView.trailingAnchor, constant: 0),
            containerView.topAnchor.constraint(equalTo: TabContainerView.topAnchor, constant: 0),
            containerView.bottomAnchor.constraint(equalTo: TabContainerView.bottomAnchor, constant: 0),
            ])
        
        
        let controller = storyboard!.instantiateViewController(withIdentifier: "DonationVC") as! DonationVC
        addChild(controller)
        controller.view.translatesAutoresizingMaskIntoConstraints = false
        TabContainerView.addSubview(controller.view)
        
        NSLayoutConstraint.activate([
            controller.view.leadingAnchor.constraint(equalTo: TabContainerView.leadingAnchor),
            controller.view.trailingAnchor.constraint(equalTo: TabContainerView.trailingAnchor),
            controller.view.topAnchor.constraint(equalTo: TabContainerView.topAnchor),
            controller.view.bottomAnchor.constraint(equalTo: TabContainerView.bottomAnchor)
            ])
        
        controller.didMove(toParent: self)
        
    }
    
    @IBAction func btnMyFavouriteClick(_ sender: Any) {
        
        strDate = ""
        EndDate = ""
        GotfirstTime = ""
        GotlastTime = ""
        GotMile = ""
        GotCatID = ""
        selectedCat = ""
        GotRelID = ""
        selectedRligion = ""
        GotChurchID = ""
        selectedCurch = ""
        isfilter = false
        
        TabContainerView.subviews.forEach({ $0.removeFromSuperview() })
        let containerView = UIView()
        containerView.translatesAutoresizingMaskIntoConstraints = false
        TabContainerView.addSubview(containerView)
        
        Tab3customeView.isHidden = false
        
        Tab1CustomeView.isHidden = true
        Tab2CustomeView.isHidden = true
        Tab4customeView.isHidden = true
        Tab5CustomeView.isHidden = true
        
        NSLayoutConstraint.activate([
            containerView.leadingAnchor.constraint(equalTo: TabContainerView.leadingAnchor, constant: 0),
            containerView.trailingAnchor.constraint(equalTo: TabContainerView.trailingAnchor, constant: 0),
            containerView.topAnchor.constraint(equalTo: TabContainerView.topAnchor, constant: 0),
            containerView.bottomAnchor.constraint(equalTo: TabContainerView.bottomAnchor, constant: 0),
            ])
        
        
        let controller = storyboard!.instantiateViewController(withIdentifier: "FavouriteVC") as! FavouriteVC
        addChild(controller)
        controller.view.translatesAutoresizingMaskIntoConstraints = false
        TabContainerView.addSubview(controller.view)
        
        NSLayoutConstraint.activate([
            controller.view.leadingAnchor.constraint(equalTo: TabContainerView.leadingAnchor),
            controller.view.trailingAnchor.constraint(equalTo: TabContainerView.trailingAnchor),
            controller.view.topAnchor.constraint(equalTo: TabContainerView.topAnchor),
            controller.view.bottomAnchor.constraint(equalTo: TabContainerView.bottomAnchor)
            ])
        
        controller.didMove(toParent: self)
        
    }
    
    func OpenConnectionReqByNotification() {
        
        strDate = ""
        EndDate = ""
        GotfirstTime = ""
        GotlastTime = ""
        GotMile = ""
        GotCatID = ""
        selectedCat = ""
        GotRelID = ""
        selectedRligion = ""
        GotChurchID = ""
        selectedCurch = ""
        isfilter = false
        
        TabContainerView.subviews.forEach({ $0.removeFromSuperview() })
        let containerView = UIView()
        containerView.translatesAutoresizingMaskIntoConstraints = false
        TabContainerView.addSubview(containerView)
        
        Tab4customeView.isHidden = false
        
        Tab1CustomeView.isHidden = true
        Tab2CustomeView.isHidden = true
        Tab3customeView.isHidden = true
        Tab5CustomeView.isHidden = true
        
        NSLayoutConstraint.activate([
            containerView.leadingAnchor.constraint(equalTo: TabContainerView.leadingAnchor, constant: 0),
            containerView.trailingAnchor.constraint(equalTo: TabContainerView.trailingAnchor, constant: 0),
            containerView.topAnchor.constraint(equalTo: TabContainerView.topAnchor, constant: 0),
            containerView.bottomAnchor.constraint(equalTo: TabContainerView.bottomAnchor, constant: 0),
            ])
        
        
        let controller = storyboard!.instantiateViewController(withIdentifier: "MyConnectionVC") as! MyConnectionVC
        controller.isConnectionRequest = true
        addChild(controller)
        controller.view.translatesAutoresizingMaskIntoConstraints = false
        TabContainerView.addSubview(controller.view)
        
        NSLayoutConstraint.activate([
            controller.view.leadingAnchor.constraint(equalTo: TabContainerView.leadingAnchor),
            controller.view.trailingAnchor.constraint(equalTo: TabContainerView.trailingAnchor),
            controller.view.topAnchor.constraint(equalTo: TabContainerView.topAnchor),
            controller.view.bottomAnchor.constraint(equalTo: TabContainerView.bottomAnchor)
            ])
        
        controller.didMove(toParent: self)
    }
    
    @IBAction func btnMyConnectionClick(_ sender: Any) {
        
        strDate = ""
        EndDate = ""
        GotfirstTime = ""
        GotlastTime = ""
        GotMile = ""
        GotCatID = ""
        selectedCat = ""
        GotRelID = ""
        selectedRligion = ""
        GotChurchID = ""
        selectedCurch = ""
        isfilter = false
        
        TabContainerView.subviews.forEach({ $0.removeFromSuperview() })
        let containerView = UIView()
        containerView.translatesAutoresizingMaskIntoConstraints = false
        TabContainerView.addSubview(containerView)
        
        Tab4customeView.isHidden = false
        
        Tab1CustomeView.isHidden = true
        Tab2CustomeView.isHidden = true
        Tab3customeView.isHidden = true
        Tab5CustomeView.isHidden = true
        
        NSLayoutConstraint.activate([
            containerView.leadingAnchor.constraint(equalTo: TabContainerView.leadingAnchor, constant: 0),
            containerView.trailingAnchor.constraint(equalTo: TabContainerView.trailingAnchor, constant: 0),
            containerView.topAnchor.constraint(equalTo: TabContainerView.topAnchor, constant: 0),
            containerView.bottomAnchor.constraint(equalTo: TabContainerView.bottomAnchor, constant: 0),
            ])
        
        
        let controller = storyboard!.instantiateViewController(withIdentifier: "MyConnectionVC") as! MyConnectionVC
        addChild(controller)
        controller.view.translatesAutoresizingMaskIntoConstraints = false
        TabContainerView.addSubview(controller.view)
        
        NSLayoutConstraint.activate([
            controller.view.leadingAnchor.constraint(equalTo: TabContainerView.leadingAnchor),
            controller.view.trailingAnchor.constraint(equalTo: TabContainerView.trailingAnchor),
            controller.view.topAnchor.constraint(equalTo: TabContainerView.topAnchor),
            controller.view.bottomAnchor.constraint(equalTo: TabContainerView.bottomAnchor)
            ])
        
        controller.didMove(toParent: self)
        
    }
    
    @IBAction func btnMymessageClick(_ sender: Any) {
        
        strDate = ""
        EndDate = ""
        GotfirstTime = ""
        GotlastTime = ""
        GotMile = ""
        GotCatID = ""
        selectedCat = ""
        GotRelID = ""
        selectedRligion = ""
        GotChurchID = ""
        selectedCurch = ""
        isfilter = false
        
        TabContainerView.subviews.forEach({ $0.removeFromSuperview() })
        let containerView = UIView()
        containerView.translatesAutoresizingMaskIntoConstraints = false
        TabContainerView.addSubview(containerView)
        
        Tab5CustomeView.isHidden = false
        
        Tab1CustomeView.isHidden = true
        Tab2CustomeView.isHidden = true
        Tab3customeView.isHidden = true
        Tab4customeView.isHidden = true
        
        NSLayoutConstraint.activate([
            containerView.leadingAnchor.constraint(equalTo: TabContainerView.leadingAnchor, constant: 0),
            containerView.trailingAnchor.constraint(equalTo: TabContainerView.trailingAnchor, constant: 0),
            containerView.topAnchor.constraint(equalTo: TabContainerView.topAnchor, constant: 0),
            containerView.bottomAnchor.constraint(equalTo: TabContainerView.bottomAnchor, constant: 0),
            ])
        
        
        let controller = storyboard!.instantiateViewController(withIdentifier: "MessageVC") as! MessageVC
        addChild(controller)
        controller.view.translatesAutoresizingMaskIntoConstraints = false
        TabContainerView.addSubview(controller.view)
        
        NSLayoutConstraint.activate([
            controller.view.leadingAnchor.constraint(equalTo: TabContainerView.leadingAnchor),
            controller.view.trailingAnchor.constraint(equalTo: TabContainerView.trailingAnchor),
            controller.view.topAnchor.constraint(equalTo: TabContainerView.topAnchor),
            controller.view.bottomAnchor.constraint(equalTo: TabContainerView.bottomAnchor)
            ])
        
        controller.didMove(toParent: self)
        
    }
    
}

