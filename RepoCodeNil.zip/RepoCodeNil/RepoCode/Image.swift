//
//	Image.swift
//
//	Create by wm-nilesh on 29/6/2019
//	Copyright © 2019. All rights reserved.
//	Model file generated using JSONExport: https://github.com/Ahmed-Ali/JSONExport

import Foundation


class Image : NSObject, NSCoding{

	var createdDate : String!
	var eventId : String!
	var id : String!
	var isVideo : String!
	var mediaName : String!
	var name : String!
	var status : String!
	var thumbMediaName : String!
	var updatedDate : String!


	/**
	 * Instantiate the instance using the passed dictionary values to set the properties values
	 */
	init(fromDictionary dictionary: [String:Any]){
		createdDate = dictionary["createdDate"] as? String
		eventId = dictionary["eventId"] as? String
		id = dictionary["id"] as? String
		isVideo = dictionary["isVideo"] as? String
		mediaName = dictionary["mediaName"] as? String
		name = dictionary["name"] as? String
		status = dictionary["status"] as? String
		thumbMediaName = dictionary["thumbMediaName"] as? String
		updatedDate = dictionary["updatedDate"] as? String
	}

	/**
	 * Returns all the available property values in the form of [String:Any] object where the key is the approperiate json key and the value is the value of the corresponding property
	 */
	func toDictionary() -> [String:Any]
	{
		var dictionary = [String:Any]()
		if createdDate != nil{
			dictionary["createdDate"] = createdDate
		}
		if eventId != nil{
			dictionary["eventId"] = eventId
		}
		if id != nil{
			dictionary["id"] = id
		}
		if isVideo != nil{
			dictionary["isVideo"] = isVideo
		}
		if mediaName != nil{
			dictionary["mediaName"] = mediaName
		}
		if name != nil{
			dictionary["name"] = name
		}
		if status != nil{
			dictionary["status"] = status
		}
		if thumbMediaName != nil{
			dictionary["thumbMediaName"] = thumbMediaName
		}
		if updatedDate != nil{
			dictionary["updatedDate"] = updatedDate
		}
		return dictionary
	}

    /**
    * NSCoding required initializer.
    * Fills the data from the passed decoder
    */
    @objc required init(coder aDecoder: NSCoder)
	{
         createdDate = aDecoder.decodeObject(forKey: "createdDate") as? String
         eventId = aDecoder.decodeObject(forKey: "eventId") as? String
         id = aDecoder.decodeObject(forKey: "id") as? String
         isVideo = aDecoder.decodeObject(forKey: "isVideo") as? String
         mediaName = aDecoder.decodeObject(forKey: "mediaName") as? String
         name = aDecoder.decodeObject(forKey: "name") as? String
         status = aDecoder.decodeObject(forKey: "status") as? String
         thumbMediaName = aDecoder.decodeObject(forKey: "thumbMediaName") as? String
         updatedDate = aDecoder.decodeObject(forKey: "updatedDate") as? String

	}

    /**
    * NSCoding required method.
    * Encodes mode properties into the decoder
    */
    @objc func encode(with aCoder: NSCoder)
	{
		if createdDate != nil{
			aCoder.encode(createdDate, forKey: "createdDate")
		}
		if eventId != nil{
			aCoder.encode(eventId, forKey: "eventId")
		}
		if id != nil{
			aCoder.encode(id, forKey: "id")
		}
		if isVideo != nil{
			aCoder.encode(isVideo, forKey: "isVideo")
		}
		if mediaName != nil{
			aCoder.encode(mediaName, forKey: "mediaName")
		}
		if name != nil{
			aCoder.encode(name, forKey: "name")
		}
		if status != nil{
			aCoder.encode(status, forKey: "status")
		}
		if thumbMediaName != nil{
			aCoder.encode(thumbMediaName, forKey: "thumbMediaName")
		}
		if updatedDate != nil{
			aCoder.encode(updatedDate, forKey: "updatedDate")
		}

	}

}