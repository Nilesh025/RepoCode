//
//  APIManager.swift
//
//  Created by Developer on 21/03/18.
//  Copyright © 2018 Developer. All rights reserved.
//

import UIKit
import Foundation
import SystemConfiguration
import MobileCoreServices
import Alamofire
//import SVProgressHUD

class APIManager: NSObject {
    
    typealias APIManagerResponseHandler = (NSDictionary)->()
    typealias APIManagerErrorHandler = (Int,String)->()
    
    // Check internet connection
    class func isConnectedToNetwork() -> Bool {
        var zeroAddress = sockaddr_in()
        zeroAddress.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        zeroAddress.sin_family = sa_family_t(AF_INET)
        
        guard let defaultRouteReachability = withUnsafePointer(to: &zeroAddress, {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                SCNetworkReachabilityCreateWithAddress(nil, $0)
            }
        }) else {
            return false
        }
        
        var flags: SCNetworkReachabilityFlags = []
        if !SCNetworkReachabilityGetFlags(defaultRouteReachability, &flags) {
            return false
        }
        
        let isReachable = flags.contains(.reachable)
        let needsConnection = flags.contains(.connectionRequired)
        
        return (isReachable && !needsConnection)
    }
    
    
    
    // API Call Manager
    class func APICalling(_ url: String,_ parameters:NSMutableDictionary,isShowProgress:Bool = true, success:@escaping APIManagerResponseHandler, failure: APIManagerErrorHandler? = nil) {
        
       // if isShowProgress { Utility.showProgress("") }
        
        // common parameter
//        parameters.setValue(Constant.kLangType, forKey: "langType")
//        parameters.setValue(Constant.kDeviceType, forKey: "deviceType")
//        parameters.setValue(Constant.kDeviceToken, forKey: "deviceToken")
//        parameters.setValue(TimeZone.current.identifier, forKey: "timeZone")
//        parameters.setValue(UIDevice.current.identifierForVendor!.uuidString, forKey: "deviceId")
        
       // parameters.setValue(Constant.UserInfo.token, forKey: "token")
       
        let jsonObject : NSMutableDictionary = NSMutableDictionary()
        jsonObject.setObject(parameters, forKey: "data" as NSCopying)
        
        let headers = [ "Content-Type": "application/json",
                        "pnp_access_key": "sift_app_access_api_pnp" ]
        
        var request =  URLRequest(url: URL(string: url)!)
        request.httpMethod = "POST"
        request.httpBody = try? JSONSerialization.data(withJSONObject: jsonObject)
        request.allHTTPHeaderFields = headers
        
        if APIManager.isConnectedToNetwork() {
            Alamofire.request(request).responseJSON { (response) in
                print("\n\n\nRequest URL :- \(request)\nParameters :- \(jsonObject)")
                
               // if isShowProgress { Utility.dismissProgress() }
                
                if let jsonDict = response.result.value as? NSDictionary {
                    print("Response :- \(jsonDict)\n\n\n")
                    
                    let message  = jsonDict.value(forKey: "message") as! String
                    let status  = jsonDict.value(forKey: "status") as! String
                    
                    success(jsonDict)
                    
                } else if response.error != nil {
                    let error = response.error?.localizedDescription ?? "Constant.ErrorMessage.kCommanError"
                    print("Error :- \(error)\n\n\n")
                    if isShowProgress {
                       // Utility.showAlert(Constant.ErrorMessage.kTitle, message: error)
                    }
                    failure?(2, error)
                } else {
                    if isShowProgress {
                        //Utility.showAlert(Constant.ErrorMessage.kTitle, message: Constant.ErrorMessage.kCommanError)
                    }
                   // failure?(1, Constant.ErrorMessage.kCommanError)
                }
            }
            
        } else {
            if isShowProgress {
               // Utility.dismissProgress()
                //Utility.showAlert(Constant.ErrorMessage.kTitle, message: Constant.ErrorMessage.kNoInternetConnection)
            }
            failure?(0, "Constant.ErrorMessage.kNoInternetConnection")
        }
    }
    
    class func upload(media:NSMutableArray,
                      andParam parameters:NSMutableDictionary,
                      success:@escaping (NSDictionary)->(),
                      progressHandler:@escaping(_ progress: Double)->Void) {
        let arrImages = NSMutableArray()
        let arrVideos = NSMutableArray()
        
        for asset in media {
            if asset is UIImage {
                arrImages.add(asset)
            }
            if asset is URL {
                arrVideos.add(asset)
            }
        }
        
        fileUpload1(images: arrImages,
                   videos: arrVideos,
                   audios: NSMutableArray(),
                   parameters: parameters,
                   success: success,
                   progressHandler: progressHandler)
        
       
    }
    
    // Image Uploading
    public class func fileUpload1(images:NSMutableArray, videos:NSMutableArray, audios:NSMutableArray, parameters:NSMutableDictionary, success:@escaping (NSDictionary)->(),progressHandler:@escaping(_ progress: Double)->Void) {
        /*
         let appDelegate = UIApplication.shared.delegate as! AppDelegate
         appDelegate.registerBackgroundTask()
         */
        let headers = [ "Content-Type": "multipart/form-data" ]
        
        var request =  URLRequest(url: URL(string: "Constant.ServerAPI.kImgUploadURL")!)
        request.httpMethod = "POST"
        request.timeoutInterval = 600 // seconds
        request.allHTTPHeaderFields = headers
        
        if APIManager.isConnectedToNetwork() {
            
            //Utility.showProgress("")
            Alamofire.upload(multipartFormData: { multipartFormData in
                for i in 0..<images.count {
                    
                    let rotatedImage = images[i] as! UIImage
                    /*
                     if let imgData = UIImageJPEGRepresentation(rotatedImage.fixOrientation(), 0.8) {
                     multipartFormData.append(imgData, withName: "image[]",fileName: "0\(i).jpg", mimeType: "image/jpg")
                     }
                     */
                    
                 //   let imgDat = rotatedImage.jpegData(compressionQuality: 0.0001)
                   
                    if let imgData = rotatedImage.pngData(){
                        multipartFormData.append(imgData, withName: "files[\(i)]",fileName: "0\(i).png", mimeType: "image/png")
                        //multipartFormData.append(imgData, withName: "files")
                    }
                }
                for (i,video) in videos.enumerated() {
                    if  let videoURL = video as? URL {
                        multipartFormData.append(videoURL, withName: "files",fileName: "video\(i).mp4", mimeType: "video/mp4")
                        //multipartFormData.append(videoURL, withName: "files")
                        /*
                         if let data = try? Data(contentsOf: videoURL) {
                         multipartFormData.append(data, withName: "files")
                         }*/
                    }
                }
                for (_,audio) in audios.enumerated() {
                    if  let audioURL = audio as? URL {
                        //multipartFormData.append(audioURL, withName: "audio", fileName: "audio\(i).m4a", mimeType: "audio/m4a")
                        
                        multipartFormData.append(audioURL, withName: "files")
                    }
                }
                for (key, value) in parameters {
                    multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key as! String)
                }
               // multipartFormData.append(GetAPIToken().data(using: String.Encoding(rawValue: String.Encoding.utf8.rawValue))!, withName: "token")
            }, with: request) { (result) in
                //print("\n\n\nRequest URL :- \(Constant.ServerAPI.kImgUploadURL)\nParameters :- \(parameters)")
                switch result {
                case .success(let upload, _, _):
                    
                    upload.uploadProgress(closure: { (progress) in
                        
                       // Utility.updateProgress(value: Float(progress.fractionCompleted))
                        print("Upload Progress: \(progress.fractionCompleted)")
                        progressHandler(progress.fractionCompleted)
                        
                    })
                    
                    upload.responseJSON { response in
                        //Utility.dismissProgress()
                        if let jsonDict = response.result.value as? NSDictionary {
                            print("Response :- \(jsonDict)\n\n\n")
                            
                            let status  = jsonDict.value(forKey: "status") as! String
                            if status == "1"{
                                
                                success(jsonDict)
                                
                            } else {
                                let msg  = jsonDict.value(forKey: "message") as! String
                                //Utility.showAlert(Constant.ErrorMessage.kTitle, message: msg)
                            }
                            
                        } else if response.error != nil {
                           // print("Error :- \((response.error?.localizedDescription)!)\n\n\n")
                           // Utility.showAlert(Constant.ErrorMessage.kTitle, message: Constant.ErrorMessage.kCommanError)
                        } else {
                            //print("Error :- \(Constant.ErrorMessage.kCommanError)\n\n\n")
                            //Utility.showAlert(Constant.ErrorMessage.kTitle, message: Constant.ErrorMessage.kCommanError)
                        }
                    }
                    
                    upload.responseData(completionHandler: { (data) in
                        //Utility.dismissProgress()
                        print(data)
                        //print(data.data?.html2String)
                    })
                    
                case .failure(let encodingError):
                    //Utility.dismissProgress()
                    print("Error :- \(encodingError.localizedDescription)\n\n\n")
                    //Utility.showAlert(Constant.ErrorMessage.kTitle, message: Constant.ErrorMessage.kCommanError)
                }
                
            }
        } else {
            //Utility.showAlert(Constant.ErrorMessage.kTitle, message: Constant.ErrorMessage.kNoInternetConnection)
        }
    }
    
    
   
    
    // Image Uploading
    class func fileUpload(images:NSMutableArray, videoURL:URL?, audioURL:URL? = nil, parameters:NSMutableDictionary, success:@escaping (NSDictionary)->(),progressHandler:@escaping(_ progress: Double)->Void) {
        /*
         let appDelegate = UIApplication.shared.delegate as! AppDelegate
         appDelegate.registerBackgroundTask()
         */
        let headers = [ "Content-Type": "multipart/form-data" ]
        
        var request =  URLRequest(url: URL(string: "Constant.ServerAPI.kImgUploadURL")!)
        request.httpMethod = "POST"
        request.timeoutInterval = 600 // seconds
        request.allHTTPHeaderFields = headers
        
        if APIManager.isConnectedToNetwork() {
            //SVProgressHUD.show()
            Alamofire.upload(multipartFormData: { multipartFormData in
                for i in 0..<images.count {
                    
                    let rotatedImage = images[i] as! UIImage
                    /*
                     if let imgData = UIImageJPEGRepresentation(rotatedImage.fixOrientation(), 0.8) {
                     multipartFormData.append(imgData, withName: "image[]",fileName: "0\(i).jpg", mimeType: "image/jpg")
                     }
                     */
                    if let imgData = rotatedImage.pngData() {
                        multipartFormData.append(imgData, withName: "files",fileName: "0\(i).png", mimeType: "image/jpg")
                    }
                }
                if videoURL != nil {
                    multipartFormData.append(videoURL!, withName: "video",fileName: "SelfIntroVideo.mp4", mimeType: "video/mp4")
                }
                if audioURL != nil {
                    multipartFormData.append(audioURL!, withName: "audio", fileName: "audio.m4a", mimeType: "audio/m4a")
                }
                for (key, value) in parameters {
                    multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key as! String)
                }
               // multipartFormData.append(Constant.UserInfo.token.data(using: String.Encoding(rawValue: String.Encoding.utf8.rawValue))!, withName: "token")
            }, with: request) { (result) in
                //print("\n\n\nRequest URL :- \(Constant.ServerAPI.kImgUploadURL)\nParameters :- \(parameters)")
                switch result {
                case .success(let upload, _, _):
                    
                    upload.uploadProgress(closure: { (progress) in
                        
                        //SVProgressHUD.showProgress(Float(progress.fractionCompleted))
                        print("Upload Progress: \(progress.fractionCompleted)")
                        progressHandler(progress.fractionCompleted)
                        
                    })
                    
                    upload.responseJSON { response in
                        
                       // SVProgressHUD.dismiss()
                        
                        if let jsonDict = response.result.value as? NSDictionary {
                            print("Response :- \(jsonDict)\n\n\n")
                            
                            let status  = jsonDict.value(forKey: "status") as? String ?? "0"
                            if status == "1"{
                                
                                success(jsonDict)
                                
                            } else {
                                let msg  = jsonDict.value(forKey: "message") as! String
                                //Utility.showAlert(Constant.ErrorMessage.kTitle, message: msg)
                            }
                            
                        } else if response.error != nil {
                           // print("Error :- \((response.error?.localizedDescription)!)\n\n\n")
                           // Utility.showAlert(Constant.ErrorMessage.kTitle, message: Constant.ErrorMessage.kCommanError)
                        } else {
                            //print("Error :- \(Constant.ErrorMessage.kCommanError)\n\n\n")
                            //Constant.ErrorMessage.kCommanError)
                        }
                    }
                    
                    upload.responseData(completionHandler: { (data) in
                        print(data)
                        //print(data.data?.html2String)
                    })
                    
                case .failure(let encodingError):
                    
                   // SVProgressHUD.dismiss()
                    print("Error :- \(encodingError.localizedDescription)\n\n\n")
                    //Utility.showAlert(Constant.ErrorMessage.kTitle, message: Constant.ErrorMessage.kCommanError)
                }
                
            }
        } else {
           // Utility.showAlert(Constant.ErrorMessage.kTitle, message: Constant.ErrorMessage.kNoInternetConnection)
        }
    }
    
}
