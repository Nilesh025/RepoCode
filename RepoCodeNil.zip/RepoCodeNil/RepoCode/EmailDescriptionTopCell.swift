//
//  EmailDescriptionTopCell.swift
//  Prujekt
//
//  Created by devwm04 on 15/11/19.
//  Copyright © 2019 webmigrates. All rights reserved.
//

import UIKit

class EmailDescriptionTopCell: UITableViewCell {

    var arrAttchment : [ModelSinglePostAttachment]!
    
    @IBOutlet weak var imgProfile: UIImageView!
    @IBOutlet weak var btnreply: UIButton!
    @IBOutlet weak var btnDelete: UIButton!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var lblSubjectName: UILabel!
    @IBOutlet weak var lblDescription: UILabel!
    @IBOutlet weak var tblAttachment: UITableView!
    @IBOutlet weak var tblHeight: NSLayoutConstraint!
    @IBOutlet weak var imgReplay: UIImageView!
    @IBOutlet weak var imgDelete: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func SettableData() {
        tblAttachment.dataSource = self
        tblAttachment.delegate = self
        tblAttachment.registerCell(withNib: "PostJobDocumentCell")
        tblAttachment.reloadData()
        if arrAttchment.count == 0 {
            tblHeight.constant = 0.0
        }
        self.layoutIfNeeded()
        
        //(self.superview as! UITableView).reloadData()
    }
    
}
extension EmailDescriptionTopCell : UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrAttchment.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : PostJobDocumentCell = tableView.dequeueReusableCell(withIdentifier: "PostJobDocumentCell", for: indexPath) as! PostJobDocumentCell
        cell.lblFileName.text = "Attachment \(indexPath.row + 1)"
        cell.btnDeleteFile.tag = indexPath.row
        let DocumentType = (arrAttchment[indexPath.row]).name.suffix(4)
        if DocumentType == ".pdf"{
            cell.imgDocumentType.image = UIImage(named: "pdf.png")
        }else if DocumentType == ".png" || DocumentType == ".jpg"{
            cell.imgDocumentType.image = UIImage(named: "photo_attach.png")
        }else {
            cell.imgDocumentType.image = UIImage(named: "doc.png")
        }
        cell.btnDeleteFile.isHidden = true
        self.tblHeight.constant = CGFloat(self.arrAttchment.count*60)
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let tempobj = arrAttchment[indexPath.row]
        if #available(iOS 10.0, *) {
            UIApplication.shared.open(URL(string: tempobj.nameUrl)!, options: [:], completionHandler: nil)
        } else {
            // Fallback on earlier versions
        }
    }
}
