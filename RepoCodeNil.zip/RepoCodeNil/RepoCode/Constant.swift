//
//  Constant.swift
//  RepoCode
//
//  Created by Nilesh Desai on 18/11/19.
//  Copyright © 2019 Nilesh Desai. All rights reserved.
//

import Foundation


class Constant: NSObject {

struct ServerAPI {
    
    // Base URL & Image Upload URL
    static let kBaseURL                         = "http://3.92.214.178/globalpraise/api/"
    
    static let kSignUpURL                       =   kBaseURL + "auth/signup"


    }

}
