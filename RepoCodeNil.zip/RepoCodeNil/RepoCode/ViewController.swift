//
//  ViewController.swift
//  RepoCode
//
//  Created by Nilesh Desai on 18/11/19.
//  Copyright © 2019 Nilesh Desai. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {
    
    var totalPage = 1

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    func callAPIForLogin()
    {
        if Connectivity.isConnectedToInternet()
        {
            print("Yes! internet is available.")
            //KRProgressHUD.show()
            //let currentTimeZone = getCurrentTimeZone()
//            let strEmail : String = txtEmail.text!.trim()
//            let strPassword : String = self.txtPassword.text!
            let dictParam = NSMutableDictionary()
//            dictParam.setValue(UIDevice.current.identifierForVendor!.uuidString, forKey: "devicetoken")
//            dictParam.setValue("1", forKey: "devicetype")
//            dictParam.setValue(strEmail, forKey: "email")
//            dictParam.setValue(1, forKey: "langType")
//            dictParam.setValue(strPassword, forKey: "password")
//            dictParam.setValue("2", forKey: "role")
//            dictParam.setValue(currentTimeZone, forKey: "timeZone")
            var dictParameter = [String:Any]()
            dictParameter["data"] = dictParam
            
            let urlString = "SERVICE_URL" + "api/auth/login"
            //let urlString = SERVICE_URL + "auth/login"
            print(dictParam)
            
            let headers: HTTPHeaders = ["Accept": "application/json"]
            Alamofire.request(urlString, method: .post, parameters: dictParameter,encoding: JSONEncoding.default, headers: headers).responseJSON {
                response in
                DispatchQueue.main.async {
                   // KRProgressHUD.dismiss()
                    switch response.result {
                    case .success(let json):
                        if let dictResult = json as? [String: Any]
                        {
                            print(dictResult)
                            if dictResult["status"] as? String == "0"
                            {
                                //self.showDefaultAlert(message: dictResult["message"] as? String ?? "")
                            }
                            else if dictResult["status"] as? String == "1"
                            {
                                let dicUserInformations = dictResult["data"] as? [String : Any] ?? [String : Any]()
                                let encodedData: Data = NSKeyedArchiver.archivedData(withRootObject: dicUserInformations)
                                UserDefaults.standard.set(encodedData, forKey: "USER_DATA")
                               // self.view.makeToast(dictResult["message"] as? String, duration: 3.0, position: .bottom)
                                let dicTemp : NSMutableDictionary = NSMutableDictionary(dictionary: dictResult["data"] as! NSDictionary)
                                UserDefaults.standard.set(dicTemp.value(forKey: "token") as! String, forKey: "token")
                                //userLogin()
                            }
                            else if dictResult["status"] as? String == "2"
                            {
                                //self.showDefaultAlert(message: dictResult["message"] as? String ?? "")
                            }
                        }
                        break
                    case .failure(let error):
                        //KRProgressHUD.dismiss()
                        //self.showDefaultAlert(message: error.localizedDescription)
                        print(error.localizedDescription)
                    }
                }
            }
        }
        else
        {
            print("No internet connection.")
        }
    }
    
    
    
    
    
    //Metho -2//////
    
    
    func callWSForLoginUser() {
        
        
        
//        let param: NSMutableDictionary = ["langType": "1",
//                                          "email": txt1.text!,
//                                          "password": txt2.text!,
//                                          "role": kAppDelegate.role,
//                                          "deviceType": "1",
//                                          "deviceToken": Constant.kDeviceToken,
//                                          "deviceId": UIDevice.current.identifierForVendor!.uuidString,
//                                          "timeZone": TimeZone.current.identifier,
//                                          "location": Address,
//                                          "latitude": GotLat,
//                                          "longitude": GotLog]
        
        let param: NSMutableDictionary = ["langType": "1"]
        
        
        
        APIManager.APICalling(Constant.ServerAPI.kSignUpURL, param, success: { (responseDic) in
            
            let msg = responseDic["message"] as? String ?? ""
            let status = responseDic["status"] as? String ?? ""
            
            if let totalPage = responseDic["total_page"] as? String {
                self.totalPage = Int(totalPage)!
            } else {
                self.totalPage = 0
            }
            
            if status == "1" {
                
                if let data = responseDic["data"] as? [String:Any] {
                    
                   
                    
                }
                
//                if let UDData = USERDEFAULTS.value(forKey: "UD_USER_INFO") as? Data,
//                    let model = NSKeyedUnarchiver.unarchiveObject(with: UDData) as? UserInfo {
//                    
//                }
                
                
            }
            else if status == "1" {
               // self.tblView.showEmptyListMessage("")
                if let data = responseDic["data"] as? [[String:Any]] {
                    if data.count > 0 {
                        
                       // if page == 1 {
                           // self.arrAllEvent.removeAll()
                       // }
                        for item in data {
                           // self.arrAllEvent.append(AllEvent.init(fromDictionary: item))
                            
                        }
                        
                        //self.btnMapClick(UIButton())
                        
                        //self.tblView.reloadData()
                        
                    }
                    
                }
                
            }
            else if status == "3" {
                
                
                
            } else if status == "4" {
              
                
            } else {
               // Utility.showAlert(Constant.ErrorMessage.kTitle, message: msg)
            }
            
        }) { (status, msg) in
            //
        }
        
    }



}

class Connectivity
{
    class func isConnectedToInternet() -> Bool
    {
        return NetworkReachabilityManager()?.isReachable ?? false
    }
}

//MARK:- STRING EXTENSION
extension String
{
    func trim() -> String
    {
        return self.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

extension UIScrollView {
    func showEmptyListMessage(_ message:String) {
        let rect = CGRect(origin: CGPoint(x: 0,y :0), size: CGSize(width: self.bounds.size.width, height: self.bounds.size.height))
        let messageLabel = UILabel(frame: rect)
        messageLabel.text = message
        messageLabel.textColor = .black
        messageLabel.numberOfLines = 0
        messageLabel.textAlignment = .center
        messageLabel.font = UIFont.systemFont(ofSize: 15)
        messageLabel.sizeToFit()
        
        if let `self` = self as? UITableView {
            self.backgroundView = messageLabel
            self.separatorStyle = .none
        } else if let `self` = self as? UICollectionView {
            self.backgroundView = messageLabel
        }
    }
}


//TBL Method

//func numberOfSections(in tableView: UITableView) -> Int {
//    return 1
//}
//func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//
//    return arrAllEvent.count
//}
//func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//    let cell : EventsCell = tableView.dequeueReusableCell(withIdentifier: "EventsCell") as! EventsCell
//
//    let arrData = arrAllEvent[indexPath.row]
//
//    cell.imgEvent.setImageFromURL(arrData.eventImage,UIImage(named: "img_Placholder")!)
//    cell.lblTitle.text = arrData.name
//    cell.lblAddress.text = arrData.location
//
//    let ConnectionImg = arrData.isFriend
//    if ConnectionImg == "0" {
//        cell.imgConnection.isHidden = false
//        cell.imgConnection.image = UIImage(named: "connection")
//    }
//    else if ConnectionImg == "1"  {
//        cell.imgConnection.isHidden = false
//        cell.imgConnection.image = UIImage(named: "MsgBtn")
//    }
//    else{
//        cell.imgConnection.isHidden = true
//    }
//
//    if self.UserId == arrData.userId {
//        cell.imgConnection.isHidden = true
//    }
//
//    let FavImg = arrData.isFavourite
//    if FavImg == "0" {
//        cell.imgHeart.image = UIImage(named: "heart-dislike")
//    }
//    else {
//        cell.imgHeart.image = UIImage(named: "heart-like")
//    }
//
//    cell.lblDate.text = arrData.startEventDate
//    cell.lblDays.text = arrData.startEventDay
//    cell.lblMonthName.text = arrData.startEventMonth
//    cell.lbltime.text = arrData.startEventTime
//
//
//    cell.btnLikePress.tag = indexPath.row
//    cell.btnLikePress.addTarget(self, action: #selector(BtnLikeClick), for: .touchUpInside)
//
//    cell.btnConnection.tag = indexPath.row
//    cell.btnConnection.addTarget(self, action: #selector(BtnConnectionClick), for: .touchUpInside)
//
//    return cell
//}
//
//func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
//
//    if scrollView == tblView {
//
//        if ((scrollView.contentOffset.y + scrollView.frame.size.height) >= scrollView.contentSize.height)
//        {
//            let count = arrAllEvent.count - 3
//            if count == arrAllEvent.count-3 && pageNumberCount < totalPage {
//                pageNumberCount += 1
//                if(CheckBtn){
//                    self.callWSForGetAllEvent(page: pageNumberCount, Publick: "1")
//                }
//                else{
//                    self.callWSForGetPrivateEvent(page: pageNumberCount, Publick: "2")
//                }
//            }
//        }
//    }
//}
//
//@objc func BtnConnectionClick(_ sender: UIButton)
//{
//
//    let point = sender.convert(CGPoint.zero, to: tblView)
//    if let indexPath = tblView.indexPathForRow(at: point) {
//
//        let data = arrAllEvent[indexPath.row]
//
//        if data.isFriend == "0" {
//
//            self.callWSForSendConnectionRequest(for: indexPath)
//        }
//
//        if data.isFriend == "1" {
//
//            let vc = ChatVC.initVC()
//            vc.ChatId = data.userId
//            vc.isGroup = false
//            self.navigationController?.pushViewController(vc, animated: true)
//
//        }
//    }
//}

//func callWSForSendConnectionRequest(for indexPath: IndexPath) {
//    
//    let Data = arrAllEvent[indexPath.row]
//    
//    let param: NSMutableDictionary = ["langType": "1",
//                                      "token": GetAPIToken(),
//                                      "friend_id": Data.userId]
//    
//    APIManager.APICalling(Constant.ServerAPI.kSendConnectionRequestURL, param, success: { (responseDic) in
//        
//        let msg = responseDic["message"] as? String ?? ""
//        let status = responseDic["status"] as? String ?? ""
//        
//        if status == "1" {
//            
//            if(self.CheckBtn){
//                Data.isFriend = (Data.isFriend == "0") ? "2" : "1"
//                self.arrAllEvent[indexPath.row] = Data
//                self.tblView.reloadRows(at: [indexPath], with: .none)
//            }else{
//                Data.isFriend = (Data.isFriend == "0") ? "2" : "1"
//                self.arrAllEvent[indexPath.row] = Data
//                self.tblView.reloadRows(at: [indexPath], with: .none)
//            }
//            
//        }
//        else {
//            Utility.showAlert(Constant.ErrorMessage.kTitle, message: msg)
//        }
//        
//    }) { (status, msg) in
//        //
//    }
//    
//}


// MARK:-
extension UICollectionView {
    func registerCell(withNib reuseIdentifier:String) {
        self.register(UINib(nibName: reuseIdentifier, bundle: Bundle.main), forCellWithReuseIdentifier: reuseIdentifier)
    }
}

// MARK:-
extension UITableView {
    func registerCell(withNib reuseIdentifier:String) {
        self.register(UINib(nibName: reuseIdentifier, bundle: Bundle.main), forCellReuseIdentifier: reuseIdentifier)
    }
}

