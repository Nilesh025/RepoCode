//
//    EventDetailModel.swift
//
//    Create by wm-nilesh on 29/6/2019
//    Copyright © 2019. All rights reserved.
//    Model file generated using JSONExport: https://github.com/Ahmed-Ali/JSONExport

import Foundation
let USERDEFAULTS                =   UserDefaults.standard

class EventDetailModel : NSObject, NSCoding{

    var categoryId : String!
    var city : String!
    var country : String!
    var createdDate : String!
    var descriptionField : String!
    var endDateTime : String!
    var eventDaysNames : [String]!
    var eventType : String!
    var fullEventDateTime : String!
    var id : String!
    var images : [Image]!
    var isFavourite : String!
    var isFriend : String!
    var latitude : String!
    var location : String!
    var longitude : String!
    var name : String!
    var organizerName : String!
    var postedBy : String!
    var religionId : String!
    var startDateTime : String!
    var startEventDay : String!
    var startEventMonth : String!
    var state : String!
    var status : String!
    var timeZoneId : String!
    var totalViews : String!
    var updatedDate : String!
    var userId : String!
    var videos : [Image]!
    var zipcode : String!
    var isAttend : String!
    var attendUserList : [String]!


    /**
     * Instantiate the instance using the passed dictionary values to set the properties values
     */
    init(fromDictionary dictionary: [String:Any]){
        categoryId = dictionary["categoryId"] as? String
        city = dictionary["city"] as? String
        country = dictionary["country"] as? String
        createdDate = dictionary["createdDate"] as? String
        descriptionField = dictionary["description"] as? String
        endDateTime = dictionary["endDateTime"] as? String
        eventDaysNames = dictionary["eventDaysNames"] as? [String]
        eventType = dictionary["eventType"] as? String
        fullEventDateTime = dictionary["fullEventDateTime"] as? String
        id = dictionary["id"] as? String
        images = [Image]()
        if let imagesArray = dictionary["images"] as? [[String:Any]]{
            for dic in imagesArray{
                let value = Image(fromDictionary: dic)
                images.append(value)
            }
        }
        isFavourite = dictionary["is_favourite"] as? String
        isFriend = dictionary["is_friend"] as? String
        latitude = dictionary["latitude"] as? String
        location = dictionary["location"] as? String
        longitude = dictionary["longitude"] as? String
        name = dictionary["name"] as? String
        organizerName = dictionary["organizerName"] as? String
        postedBy = dictionary["postedBy"] as? String
        religionId = dictionary["religionId"] as? String
        startDateTime = dictionary["startDateTime"] as? String
        startEventDay = dictionary["startEventDay"] as? String
        startEventMonth = dictionary["startEventMonth"] as? String
        state = dictionary["state"] as? String
        status = dictionary["status"] as? String
        timeZoneId = dictionary["timeZoneId"] as? String
        totalViews = dictionary["total_views"] as? String
        updatedDate = dictionary["updatedDate"] as? String
        userId = dictionary["userId"] as? String
        videos = [Image]()
        if let videosArray = dictionary["videos"] as? [[String:Any]]{
            for dic in videosArray{
                let value = Image(fromDictionary: dic)
                videos.append(value)
            }
        }
        zipcode = dictionary["zipcode"] as? String
        isAttend = dictionary["is_attend"] as? String
        attendUserList = dictionary["attendUserList"] as? [String]
    }

    /**
     * Returns all the available property values in the form of [String:Any] object where the key is the approperiate json key and the value is the value of the corresponding property
     */
    func toDictionary() -> [String:Any]
    {
        var dictionary = [String:Any]()
        if categoryId != nil{
            dictionary["categoryId"] = categoryId
        }
        if city != nil{
            dictionary["city"] = city
        }
        if country != nil{
            dictionary["country"] = country
        }
        if createdDate != nil{
            dictionary["createdDate"] = createdDate
        }
        if descriptionField != nil{
            dictionary["description"] = descriptionField
        }
        if endDateTime != nil{
            dictionary["endDateTime"] = endDateTime
        }
        if eventDaysNames != nil{
            dictionary["eventDaysNames"] = eventDaysNames
        }
        if eventType != nil{
            dictionary["eventType"] = eventType
        }
        if fullEventDateTime != nil{
            dictionary["fullEventDateTime"] = fullEventDateTime
        }
        if id != nil{
            dictionary["id"] = id
        }
        if images != nil{
            var dictionaryElements = [[String:Any]]()
            for imagesElement in images {
                dictionaryElements.append(imagesElement.toDictionary())
            }
            dictionary["images"] = dictionaryElements
        }
        if isFavourite != nil{
            dictionary["is_favourite"] = isFavourite
        }
        if isFriend != nil{
            dictionary["is_friend"] = isFriend
        }
        if latitude != nil{
            dictionary["latitude"] = latitude
        }
        if location != nil{
            dictionary["location"] = location
        }
        if longitude != nil{
            dictionary["longitude"] = longitude
        }
        if name != nil{
            dictionary["name"] = name
        }
        if organizerName != nil{
            dictionary["organizerName"] = organizerName
        }
        if postedBy != nil{
            dictionary["postedBy"] = postedBy
        }
        if religionId != nil{
            dictionary["religionId"] = religionId
        }
        if startDateTime != nil{
            dictionary["startDateTime"] = startDateTime
        }
        if startEventDay != nil{
            dictionary["startEventDay"] = startEventDay
        }
        if startEventMonth != nil{
            dictionary["startEventMonth"] = startEventMonth
        }
        if state != nil{
            dictionary["state"] = state
        }
        if status != nil{
            dictionary["status"] = status
        }
        if timeZoneId != nil{
            dictionary["timeZoneId"] = timeZoneId
        }
        if totalViews != nil{
            dictionary["total_views"] = totalViews
        }
        if updatedDate != nil{
            dictionary["updatedDate"] = updatedDate
        }
        if userId != nil{
            dictionary["userId"] = userId
        }
        if videos != nil{
            var dictionaryElements = [[String:Any]]()
            for videosElement in videos {
                dictionaryElements.append(videosElement.toDictionary())
            }
            dictionary["videos"] = dictionaryElements
        }
        if zipcode != nil{
            dictionary["zipcode"] = zipcode
        }
        if isAttend != nil{
            dictionary["is_attend"] = isAttend
        }

        if attendUserList != nil{
            dictionary["attendUserList"] = attendUserList
        }
        return dictionary
    }

    /**
    * NSCoding required initializer.
    * Fills the data from the passed decoder
    */
    @objc required init(coder aDecoder: NSCoder)
    {
         categoryId = aDecoder.decodeObject(forKey: "categoryId") as? String
         city = aDecoder.decodeObject(forKey: "city") as? String
         country = aDecoder.decodeObject(forKey: "country") as? String
         createdDate = aDecoder.decodeObject(forKey: "createdDate") as? String
         descriptionField = aDecoder.decodeObject(forKey: "description") as? String
         endDateTime = aDecoder.decodeObject(forKey: "endDateTime") as? String
         eventDaysNames = aDecoder.decodeObject(forKey: "eventDaysNames") as? [String]
         eventType = aDecoder.decodeObject(forKey: "eventType") as? String
         fullEventDateTime = aDecoder.decodeObject(forKey: "fullEventDateTime") as? String
         id = aDecoder.decodeObject(forKey: "id") as? String
         images = aDecoder.decodeObject(forKey :"images") as? [Image]
         isFavourite = aDecoder.decodeObject(forKey: "is_favourite") as? String
         isFriend = aDecoder.decodeObject(forKey: "is_friend") as? String
         latitude = aDecoder.decodeObject(forKey: "latitude") as? String
         location = aDecoder.decodeObject(forKey: "location") as? String
         longitude = aDecoder.decodeObject(forKey: "longitude") as? String
         name = aDecoder.decodeObject(forKey: "name") as? String
         organizerName = aDecoder.decodeObject(forKey: "organizerName") as? String
         postedBy = aDecoder.decodeObject(forKey: "postedBy") as? String
         religionId = aDecoder.decodeObject(forKey: "religionId") as? String
         startDateTime = aDecoder.decodeObject(forKey: "startDateTime") as? String
         startEventDay = aDecoder.decodeObject(forKey: "startEventDay") as? String
         startEventMonth = aDecoder.decodeObject(forKey: "startEventMonth") as? String
         state = aDecoder.decodeObject(forKey: "state") as? String
         status = aDecoder.decodeObject(forKey: "status") as? String
         timeZoneId = aDecoder.decodeObject(forKey: "timeZoneId") as? String
         totalViews = aDecoder.decodeObject(forKey: "total_views") as? String
         updatedDate = aDecoder.decodeObject(forKey: "updatedDate") as? String
         userId = aDecoder.decodeObject(forKey: "userId") as? String
         videos = aDecoder.decodeObject(forKey :"videos") as? [Image]
         zipcode = aDecoder.decodeObject(forKey: "zipcode") as? String
        isAttend = aDecoder.decodeObject(forKey: "is_attend") as? String
        attendUserList = aDecoder.decodeObject(forKey: "attendUserList") as? [String]

    }

    /**
    * NSCoding required method.
    * Encodes mode properties into the decoder
    */
    @objc func encode(with aCoder: NSCoder)
    {
        if categoryId != nil{
            aCoder.encode(categoryId, forKey: "categoryId")
        }
        if city != nil{
            aCoder.encode(city, forKey: "city")
        }
        if country != nil{
            aCoder.encode(country, forKey: "country")
        }
        if createdDate != nil{
            aCoder.encode(createdDate, forKey: "createdDate")
        }
        if descriptionField != nil{
            aCoder.encode(descriptionField, forKey: "description")
        }
        if endDateTime != nil{
            aCoder.encode(endDateTime, forKey: "endDateTime")
        }
        if eventDaysNames != nil{
            aCoder.encode(eventDaysNames, forKey: "eventDaysNames")
        }
        if eventType != nil{
            aCoder.encode(eventType, forKey: "eventType")
        }
        if fullEventDateTime != nil{
            aCoder.encode(fullEventDateTime, forKey: "fullEventDateTime")
        }
        if id != nil{
            aCoder.encode(id, forKey: "id")
        }
        if images != nil{
            aCoder.encode(images, forKey: "images")
        }
        if isFavourite != nil{
            aCoder.encode(isFavourite, forKey: "is_favourite")
        }
        if isFriend != nil{
            aCoder.encode(isFriend, forKey: "is_friend")
        }
        if latitude != nil{
            aCoder.encode(latitude, forKey: "latitude")
        }
        if location != nil{
            aCoder.encode(location, forKey: "location")
        }
        if longitude != nil{
            aCoder.encode(longitude, forKey: "longitude")
        }
        if name != nil{
            aCoder.encode(name, forKey: "name")
        }
        if organizerName != nil{
            aCoder.encode(organizerName, forKey: "organizerName")
        }
        if postedBy != nil{
            aCoder.encode(postedBy, forKey: "postedBy")
        }
        if religionId != nil{
            aCoder.encode(religionId, forKey: "religionId")
        }
        if startDateTime != nil{
            aCoder.encode(startDateTime, forKey: "startDateTime")
        }
        if startEventDay != nil{
            aCoder.encode(startEventDay, forKey: "startEventDay")
        }
        if startEventMonth != nil{
            aCoder.encode(startEventMonth, forKey: "startEventMonth")
        }
        if state != nil{
            aCoder.encode(state, forKey: "state")
        }
        if status != nil{
            aCoder.encode(status, forKey: "status")
        }
        if timeZoneId != nil{
            aCoder.encode(timeZoneId, forKey: "timeZoneId")
        }
        if totalViews != nil{
            aCoder.encode(totalViews, forKey: "total_views")
        }
        if updatedDate != nil{
            aCoder.encode(updatedDate, forKey: "updatedDate")
        }
        if userId != nil{
            aCoder.encode(userId, forKey: "userId")
        }
        if videos != nil{
            aCoder.encode(videos, forKey: "videos")
        }
        if zipcode != nil{
            aCoder.encode(zipcode, forKey: "zipcode")
        }
        if isAttend != nil{
            aCoder.encode(isAttend, forKey: "is_attend")
        }
        if attendUserList != nil{
            aCoder.encode(attendUserList, forKey: "attendUserList")
        }

    }
    
    func saveToUserDefaults() {
        let data = NSKeyedArchiver.archivedData(withRootObject: self)
        USERDEFAULTS.set(data, forKey: "UD_USER_INFO")
    }

}
