//
//  EmailDetailVC.swift
//  Prujekt
//
//  Created by devwm04 on 15/11/19.
//  Copyright © 2019 webmigrates. All rights reserved.
//

import UIKit

class EmailDetailVC: UIViewController {

    var MailID = String()
    var MailType = String()
    var arrEmailList = NSMutableArray()
    
    @IBOutlet weak var tblView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        tblView.registerCell(withNib: "EmailDescriptionTopCell")
        tblView.delegate = self
        tblView.dataSource = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        arrEmailList.removeAllObjects()
        GetMailDetail(mailID: MailID)
    }
    
    @IBAction func btnBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    //MARK- Button Click  Delete
    
    @objc func btnDeleteClick(sender : UIButton) {
        let altYES = UIAlertAction(title: "YES", style: .default) { (action) in
            let TempModel = self.arrEmailList[0] as! ModelEmailList
            self.DeleteMailDetail(mailID: TempModel.id)
        }
        let altNO = UIAlertAction(title: "NO", style: .default, handler: nil)
        
        showAlert("Are you sure ?", message: "Are you sure to delet this mail ?", actions: [altYES, altNO])
    }
    @objc func btnReplyClick(sender : UIButton) {
        let VC : EmailReplayVC = loadVC(strStoryboardId: SB_MAIN, strVCId: idEmailReplayVC) as! EmailReplayVC
        let TempModel = arrEmailList[0] as! ModelEmailList
        VC.MailDetail = TempModel
        self.navigationController?.pushViewController(VC, animated: true)
    }
}

extension EmailDetailVC : UITableViewDelegate, UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrEmailList.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : EmailDescriptionTopCell = tableView.dequeueReusableCell(withIdentifier: "EmailDescriptionTopCell", for: indexPath) as! EmailDescriptionTopCell
        let CurrentModel = arrEmailList[indexPath.row] as! ModelEmailList
        
        cell.imgProfile.setImageFromURL(CurrentModel.userImage ?? "")
        cell.lblUserName.text = CurrentModel.userName
        cell.lblSubjectName.text = CurrentModel.subject
        cell.lblDescription.text = CurrentModel.descriptionField
        cell.arrAttchment = CurrentModel.attachment
        cell.SettableData()
        cell.btnDelete.addTarget(self, action: #selector(self.btnDeleteClick(sender:)), for: .touchUpInside)
        cell.btnreply.addTarget(self, action: #selector(self.btnReplyClick(sender:)), for: .touchUpInside)
        if indexPath.row == 0 {
            cell.btnDelete.isHidden = false
            cell.btnreply.isHidden = false
            cell.imgDelete.isHidden = false
            cell.imgReplay.isHidden = false

        }else{
            cell.btnDelete.isHidden = true
            cell.btnreply.isHidden = true
            cell.imgDelete.isHidden = true
            cell.imgReplay.isHidden = true
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
extension EmailDetailVC{
    func GetMailDetail(mailID:String) {
        
        let param : NSMutableDictionary = ["langType" : kLengType,
                                           "token" : ModelUserInfo.getUserDataFromUserDefaults().token ?? "",
                                           "emailId": mailID,
                                           "mailType": MailType]
        
        let data : NSMutableDictionary = ["data" : param]
        
        HttpRequestManager.sharedInstance.requestWithPostJsonParam(service: kGetEmaildetail, parameters: data, showLoader: true) { (response, error) in
            if error != nil
            {
                showMessageWithRetry(RetryMessage,3, buttonTapHandler: { _ in
                    self.GetMailDetail(mailID: mailID)
                })
                return
            }
            else {
                if response?.value(forKey: kStatus) as? String ?? "" == kStatusSuccess {
                    let dic = response?.value(forKey: "data")as? [String : Any]
                    //self.MailDetail = ModelEmailList(fromDictionary: dic!)
                    self.arrEmailList.add(ModelEmailList(fromDictionary: dic!))
                    let arrDt = response?.value(forKey: "replayData")as? NSMutableArray
                    for item in arrDt! {
                        let model : ModelEmailList = ModelEmailList(fromDictionary: item as! [String : Any])
                        self.arrEmailList.add(model)
                    }

                    self.tblView.reloadData()
                }else{
                    self.parent!.showToastMessage(message: response?.value(forKey: kMessage) as? String ?? "")
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
    
    func DeleteMailDetail(mailID:String) {
        var strService = String()
        if MailType == kInboxMailType {
            strService = kDeleteReceivedEmail
        }else{
            strService = kDeleteSendingEmail
        }
        let param : NSMutableDictionary = ["langType" : kLengType,
                                           "token" : ModelUserInfo.getUserDataFromUserDefaults().token ?? "",
                                           "emailId": mailID]
        
        let data : NSMutableDictionary = ["data" : param]
        
        HttpRequestManager.sharedInstance.requestWithPostJsonParam(service: strService, parameters: data, showLoader: true) { (response, error) in
            if error != nil
            {
                showMessageWithRetry(RetryMessage,3, buttonTapHandler: { _ in
                    self.GetMailDetail(mailID: mailID)
                })
                return
            }
            else {
                if response?.value(forKey: kStatus) as? String ?? "" == kStatusSuccess {
                    self.parent!.showToastMessage(message: response?.value(forKey: kMessage) as? String ?? "")
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
